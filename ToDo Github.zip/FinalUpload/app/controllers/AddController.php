<?php 
function AddTask($task) {
    $mysqli = connect();
    $sql = $mysqli->prepare ("INSERT INTO tasks (task_name) values (?) ");
    $sql->bind_param("s",$task);
    $sql-> execute();

    
      


}
?>
