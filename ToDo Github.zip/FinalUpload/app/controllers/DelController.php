<?php

function DelTask($id) {
        $mysqli = connect();
        $sql = $mysqli->prepare ("DELETE FROM tasks WHERE id = ?");
        $sql->bind_param("i",$id);
        $sql-> execute();

    }
?>