<!DOCTYPE html>
<html>

<head>
    <style>
        * {
            box-sizing: border-box;
        }


        .header {
            background-color: #98dede;
            padding: 30px 40px;
            color: white;
            text-align: center;
        }


        .header:after {
            content: "";
            display: table;
            clear: both;
        }

        input {
            margin: 0;
            border: none;
            border-radius: 0;
            width: 75%;
            padding: 20px;
            float: left;
            font-size: 16px;
        }

        #enter {
            width: 25%;
        }



        h2 {
            background-color: #3D426B;
        }

        body {
            background-color: blueviolet;
            background-image: url("post.png");
            background-position: center;
        }

        .box {
            background-color: aliceblue;
        }

    </style>


</head>

<body>
    <?php require 'controllers/AddController.php';
    require 'models/database.php';
    require 'views/Display.php';
    require 'controllers/DelController.php';
    if (isset($_POST["tasks"])){
        AddTask($_POST["tasks"]);
    }
    if (isset($_GET["action"])&& $_GET["action"]=='del'){
        DelTask($_GET["id"]);
    }
    
 
   
   
?>
    <div id="myDIV" class="header">
        <h2> To Do List</h2>

        <form action="index.php" method="POST" class="box">
            <input type="text" id="user_input" name="tasks" placeholder="Things that need to get done because they are not going to do themselves...">
            <input type="submit" id="enter">
        </form>


        <br>

    </div>

    <ul id="ToDoUL">
        <?php display();
        ?>
    </ul>


</body>

</html>
