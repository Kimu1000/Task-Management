<div id="style">

    <?php 


function display() {
 $conn = connect();
 $sql = "SELECT id, task_name FROM tasks";
 $result = $conn->query($sql);
    
 if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
      
    echo "<table border='1'>";
    
    
    echo"<tr id ='demo'><td>{$row["task_name"]}<a href=\"index.php?action=del&id=".$row["id"]."\" >x</a></td></tr>";
  }
} else {
  echo "0 results";
}
 $conn->close();
}








date_default_timezone_set('America/NEW_YORK');
?>
</div>


<style>
    td {
        background-color: white;
        width: 1200px;



    }

    tr {
        width: 100%;
        height: 20px;
        color: black;
        font-size: 30px;
    }


    a {
        color: white;
        text-decoration: none;
        float: right;
        align-content: center;
        background-color: black;


    }

</style>
